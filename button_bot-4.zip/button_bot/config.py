"""
تنظیمات ربات - همه‌چیز از فایل .env خونده می‌شه
"""
import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

# شناسه عددی ادمین‌ها، با کاما جدا شده باشن. مثال: 123456789,987654321
_admin_ids_raw = os.getenv("ADMIN_IDS", "")
ADMIN_IDS = set()
for _part in _admin_ids_raw.split(","):
    _part = _part.strip()
    if _part.isdigit():
        ADMIN_IDS.add(int(_part))

DB_PATH = os.getenv("DB_PATH", "bot.db")

# متن پیش‌فرض خوش‌آمدگویی (در صورتی که در تنظیمات ربات چیزی ست نشده باشه)
DEFAULT_WELCOME_TEXT = "سلام 👋\nبه ربات خوش اومدی! یکی از گزینه‌های زیر رو انتخاب کن:"

# متن دکمه بازگشت
BACK_BUTTON_TEXT = "🔙 بازگشت"
MAIN_MENU_BUTTON_TEXT = "🏠 منوی اصلی"

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN در فایل .env تنظیم نشده است.")

if not ADMIN_IDS:
    raise RuntimeError("ADMIN_IDS در فایل .env تنظیم نشده است. حداقل یک آیدی عددی ادمین لازم است.")
