"""
لایه دیتابیس. از sqlite3 استاندارد پایتون استفاده می‌کنه، هیچ وابستگی بیرونی نداره.
همه‌ی توابع sync هستن ولی چون sqlite3 سریعه و I/O سبکه، مستقیم داخل هندلرهای async صدا زده می‌شن.
"""
import sqlite3
import time
from contextlib import contextmanager
from typing import Optional

from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS buttons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    parent_id INTEGER,
    text TEXT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0,
    response_type TEXT NOT NULL DEFAULT 'none',  -- none | text | photo | video | document
    response_text TEXT,
    response_file_id TEXT,
    required_points INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (parent_id) REFERENCES buttons(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS users (
    telegram_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    joined_at INTEGER NOT NULL,
    last_seen INTEGER NOT NULL,
    is_banned INTEGER NOT NULL DEFAULT 0,
    referred_by INTEGER,
    referral_credited INTEGER NOT NULL DEFAULT 0,
    points INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS admins (
    telegram_id INTEGER PRIMARY KEY,
    added_by INTEGER,
    added_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS keywords (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    response_text TEXT NOT NULL,
    match_type TEXT NOT NULL DEFAULT 'contains',  -- contains | exact
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS button_clicks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    button_id INTEGER NOT NULL,
    telegram_id INTEGER NOT NULL,
    clicked_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS required_channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_identifier TEXT NOT NULL,   -- می‌تونه @username یا -100xxxxxxxxxx باشه
    title TEXT,
    invite_link TEXT,
    chat_id INTEGER,                 -- آیدی عددی واقعی چت (برای تطبیق مطمئن رویدادهای عضویت)
    added_at INTEGER NOT NULL
);

-- رویدادهای عضویت/خروج کاربران در کانال‌های جوین اجباری (برای آمار جذب روزانه/ساعتی)
CREATE TABLE IF NOT EXISTS channel_member_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    required_channel_id INTEGER NOT NULL,
    telegram_id INTEGER,
    event_type TEXT NOT NULL,  -- join | leave
    event_at INTEGER NOT NULL,
    FOREIGN KEY (required_channel_id) REFERENCES required_channels(id) ON DELETE CASCADE
);

-- دکمه‌های امتیازی‌ای که هر کاربر قبلاً با کسر امتیاز باز کرده (تا دوباره امتیاز کسر نشه)
CREATE TABLE IF NOT EXISTS unlocked_buttons (
    telegram_id INTEGER NOT NULL,
    button_id INTEGER NOT NULL,
    unlocked_at INTEGER NOT NULL,
    PRIMARY KEY (telegram_id, button_id)
);
"""


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    # busy_timeout: به‌جای خطای فوری «database is locked»، تا ۵ ثانیه صبر می‌کنه تا نوشتن دیگه تموم بشه
    conn.execute("PRAGMA busy_timeout = 5000")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


INDEXES = """
CREATE INDEX IF NOT EXISTS idx_buttons_parent ON buttons(parent_id);
CREATE INDEX IF NOT EXISTS idx_button_clicks_button ON button_clicks(button_id);
CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users(referred_by);
CREATE INDEX IF NOT EXISTS idx_channel_events_channel_time ON channel_member_events(required_channel_id, event_at);
CREATE INDEX IF NOT EXISTS idx_unlocked_buttons_user ON unlocked_buttons(telegram_id);
"""


def init_db():
    # WAL باعث می‌شه خواندن‌ها هیچ‌وقت منتظر نوشتن‌ها نمونن (سرعت و پایداری بالاتر زیر بار).
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.close()
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        conn.executescript(INDEXES)
        _migrate(conn)


def _migrate(conn):
    """برای دیتابیس‌های قدیمی که از قبل ساخته شدن، ستون‌های جدید رو اضافه می‌کنه بدون از دست رفتن داده"""
    existing_user_cols = {row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
    if "referred_by" not in existing_user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN referred_by INTEGER")
    if "points" not in existing_user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN points INTEGER NOT NULL DEFAULT 0")
    if "referral_credited" not in existing_user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN referral_credited INTEGER NOT NULL DEFAULT 0")

    existing_button_cols = {row["name"] for row in conn.execute("PRAGMA table_info(buttons)").fetchall()}
    if "required_points" not in existing_button_cols:
        conn.execute("ALTER TABLE buttons ADD COLUMN required_points INTEGER NOT NULL DEFAULT 0")

    existing_channel_cols = {row["name"] for row in conn.execute("PRAGMA table_info(required_channels)").fetchall()}
    if "chat_id" not in existing_channel_cols:
        conn.execute("ALTER TABLE required_channels ADD COLUMN chat_id INTEGER")


# ---------- کاربران ----------

def upsert_user(telegram_id: int, username: Optional[str], first_name: Optional[str], referred_by: Optional[int] = None) -> bool:
    """
    کاربر رو ثبت/آپدیت می‌کنه. خروجی True یعنی این کاربر کاملاً تازه بوده (اولین بارشه).
    referred_by فقط برای کاربر کاملاً جدید ذخیره می‌شه؛ امتیاز به دعوت‌کننده اینجا داده نمی‌شه —
    فقط وقتی کاربرِ دعوت‌شده عضویت کانال‌های اجباری رو تایید کنه، امتیاز اعطا می‌شه
    (تابع credit_referral_if_confirmed را ببینید).
    """
    now = int(time.time())
    with get_conn() as conn:
        row = conn.execute("SELECT telegram_id FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        if row:
            conn.execute(
                "UPDATE users SET username=?, first_name=?, last_seen=? WHERE telegram_id=?",
                (username, first_name, now, telegram_id),
            )
            return False
        else:
            valid_ref = referred_by if (referred_by and referred_by != telegram_id) else None
            conn.execute(
                "INSERT INTO users (telegram_id, username, first_name, joined_at, last_seen, is_banned, referred_by, referral_credited, points) "
                "VALUES (?,?,?,?,?,0,?,0,0)",
                (telegram_id, username, first_name, now, now, valid_ref),
            )
            return True


def credit_referral_if_confirmed(telegram_id: int):
    """
    اگه این کاربر از طریق لینک رفرال اومده و هنوز امتیازش به دعوت‌کننده داده نشده،
    الان (بعد از تایید عضویت کانال‌ها) یک امتیاز به دعوت‌کننده اضافه می‌کنه.
    خروجی: دیکشنری اطلاعات دعوت‌کننده (telegram_id) اگه امتیاز تازه اعطا شده، وگرنه None.
    """
    with get_conn() as conn:
        row = conn.execute(
            "SELECT referred_by, referral_credited FROM users WHERE telegram_id=?", (telegram_id,)
        ).fetchone()
        if not row or not row["referred_by"] or row["referral_credited"]:
            return None
        referrer_id = row["referred_by"]
        conn.execute("UPDATE users SET referral_credited=1 WHERE telegram_id=?", (telegram_id,))
        conn.execute("UPDATE users SET points = points + 1 WHERE telegram_id=?", (referrer_id,))
        return referrer_id


def is_banned(telegram_id: int) -> bool:
    with get_conn() as conn:
        row = conn.execute("SELECT is_banned FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        return bool(row and row["is_banned"])


def set_ban(telegram_id: int, banned: bool) -> bool:
    """
    بن/آنبن یک کاربر. اگه کاربر قبلاً هیچ‌وقت /start نزده باشه (رکوردی نداره)،
    یک رکورد جای‌گذاری‌شده (placeholder) براش می‌سازیم تا بن واقعاً اعمال بشه.
    خروجی True یعنی کاربر از قبل تو دیتابیس بود، False یعنی تازه ساخته شد.
    """
    now = int(time.time())
    with get_conn() as conn:
        row = conn.execute("SELECT telegram_id FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        existed = bool(row)
        if existed:
            conn.execute(
                "UPDATE users SET is_banned=? WHERE telegram_id=?",
                (1 if banned else 0, telegram_id),
            )
        else:
            conn.execute(
                "INSERT INTO users (telegram_id, username, first_name, joined_at, last_seen, is_banned) "
                "VALUES (?, NULL, NULL, ?, ?, ?)",
                (telegram_id, now, now, 1 if banned else 0),
            )
        return existed


def get_all_user_ids(only_active: bool = False):
    with get_conn() as conn:
        if only_active:
            rows = conn.execute("SELECT telegram_id FROM users WHERE is_banned=0").fetchall()
        else:
            rows = conn.execute("SELECT telegram_id FROM users").fetchall()
        return [r["telegram_id"] for r in rows]


def get_stats():
    with get_conn() as conn:
        total = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
        banned = conn.execute("SELECT COUNT(*) c FROM users WHERE is_banned=1").fetchone()["c"]
        day_ago = int(time.time()) - 86400
        active_today = conn.execute(
            "SELECT COUNT(*) c FROM users WHERE last_seen >= ?", (day_ago,)
        ).fetchone()["c"]
        total_buttons = conn.execute("SELECT COUNT(*) c FROM buttons").fetchone()["c"]
        total_clicks = conn.execute("SELECT COUNT(*) c FROM button_clicks").fetchone()["c"]
        return {
            "total_users": total,
            "banned_users": banned,
            "active_today": active_today,
            "total_buttons": total_buttons,
            "total_clicks": total_clicks,
        }


def get_top_buttons(limit: int = 5):
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT b.text, COUNT(c.id) as clicks
            FROM buttons b
            LEFT JOIN button_clicks c ON c.button_id = b.id
            GROUP BY b.id
            ORDER BY clicks DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [(r["text"], r["clicks"]) for r in rows]


# ---------- دکمه‌ها ----------

def add_button(parent_id: Optional[int], text: str) -> int:
    with get_conn() as conn:
        pos_row = conn.execute(
            "SELECT COALESCE(MAX(position), -1) + 1 as p FROM buttons WHERE parent_id IS ?",
            (parent_id,),
        ).fetchone()
        position = pos_row["p"]
        cur = conn.execute(
            "INSERT INTO buttons (parent_id, text, position, response_type, created_at) VALUES (?,?,?,?,?)",
            (parent_id, text, position, "none", int(time.time())),
        )
        return cur.lastrowid


def set_button_response(button_id: int, response_type: str, response_text: Optional[str], response_file_id: Optional[str]):
    with get_conn() as conn:
        conn.execute(
            "UPDATE buttons SET response_type=?, response_text=?, response_file_id=? WHERE id=?",
            (response_type, response_text, response_file_id, button_id),
        )


def rename_button(button_id: int, new_text: str):
    with get_conn() as conn:
        conn.execute("UPDATE buttons SET text=? WHERE id=?", (new_text, button_id))


def set_button_points(button_id: int, points: int):
    with get_conn() as conn:
        conn.execute("UPDATE buttons SET required_points=? WHERE id=?", (points, button_id))


def delete_button(button_id: int):
    # فرزندان به خاطر ON DELETE CASCADE به‌صورت خودکار حذف می‌شن
    with get_conn() as conn:
        conn.execute("DELETE FROM buttons WHERE id=?", (button_id,))


def get_button(button_id: int):
    with get_conn() as conn:
        return conn.execute("SELECT * FROM buttons WHERE id=?", (button_id,)).fetchone()


def get_children(parent_id: Optional[int]):
    with get_conn() as conn:
        return conn.execute(
            "SELECT * FROM buttons WHERE parent_id IS ? ORDER BY position ASC, id ASC",
            (parent_id,),
        ).fetchall()


def move_button(button_id: int, direction: str):
    """جابه‌جایی دکمه به بالا یا پایین در بین خواهر و برادرهاش (direction: 'up' یا 'down')"""
    with get_conn() as conn:
        btn = conn.execute("SELECT * FROM buttons WHERE id=?", (button_id,)).fetchone()
        if not btn:
            return
        siblings = conn.execute(
            "SELECT * FROM buttons WHERE parent_id IS ? ORDER BY position ASC, id ASC",
            (btn["parent_id"],),
        ).fetchall()
        idx = next((i for i, s in enumerate(siblings) if s["id"] == button_id), None)
        if idx is None:
            return
        swap_idx = idx - 1 if direction == "up" else idx + 1
        if swap_idx < 0 or swap_idx >= len(siblings):
            return
        other = siblings[swap_idx]
        conn.execute("UPDATE buttons SET position=? WHERE id=?", (other["position"], button_id))
        conn.execute("UPDATE buttons SET position=? WHERE id=?", (btn["position"], other["id"]))


def log_click(button_id: int, telegram_id: int):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO button_clicks (button_id, telegram_id, clicked_at) VALUES (?,?,?)",
            (button_id, telegram_id, int(time.time())),
        )


# ---------- تنظیمات ----------

def get_setting(key: str, default: Optional[str] = None) -> Optional[str]:
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO settings (key, value) VALUES (?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


# ---------- کانال‌های جوین اجباری ----------

def add_required_channel(chat_identifier: str, title: str = None, invite_link: str = None, chat_id: int = None) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO required_channels (chat_identifier, title, invite_link, chat_id, added_at) VALUES (?,?,?,?,?)",
            (chat_identifier, title, invite_link, chat_id, int(time.time())),
        )
        return cur.lastrowid


def update_channel_link(channel_id: int, invite_link: str, chat_id: int = None):
    """لینک دعوت اختصاصی (و در صورت نیاز آیدی عددی چت) یک کانال رو بروزرسانی می‌کنه"""
    with get_conn() as conn:
        if chat_id is not None:
            conn.execute(
                "UPDATE required_channels SET invite_link=?, chat_id=? WHERE id=?",
                (invite_link, chat_id, channel_id),
            )
        else:
            conn.execute("UPDATE required_channels SET invite_link=? WHERE id=?", (invite_link, channel_id))


def remove_required_channel(channel_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM required_channels WHERE id=?", (channel_id,))


def get_required_channels():
    with get_conn() as conn:
        return conn.execute("SELECT * FROM required_channels ORDER BY id ASC").fetchall()


def get_required_channel(channel_id: int):
    with get_conn() as conn:
        return conn.execute("SELECT * FROM required_channels WHERE id=?", (channel_id,)).fetchone()


def find_required_channel_by_chat_id(chat_id: int):
    with get_conn() as conn:
        return conn.execute("SELECT * FROM required_channels WHERE chat_id=?", (chat_id,)).fetchone()


# ---------- آمار جذب اعضای کانال‌های جوین اجباری ----------

def log_channel_member_event(required_channel_id: int, telegram_id: int, event_type: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO channel_member_events (required_channel_id, telegram_id, event_type, event_at) VALUES (?,?,?,?)",
            (required_channel_id, telegram_id, event_type, int(time.time())),
        )


def get_channel_join_stats(required_channel_id: int):
    now = int(time.time())
    with get_conn() as conn:
        def count_since(event_type, since):
            q = "SELECT COUNT(*) c FROM channel_member_events WHERE required_channel_id=? AND event_type=?"
            params = [required_channel_id, event_type]
            if since is not None:
                q += " AND event_at>=?"
                params.append(since)
            return conn.execute(q, params).fetchone()["c"]

        total_join = count_since("join", None)
        total_leave = count_since("leave", None)
        return {
            "total_join": total_join,
            "total_leave": total_leave,
            "net": total_join - total_leave,
            "today": count_since("join", now - 86400),
            "week": count_since("join", now - 7 * 86400),
            "month": count_since("join", now - 30 * 86400),
        }


def get_channel_daily_breakdown(required_channel_id: int, days: int = 30):
    since = int(time.time()) - days * 86400
    with get_conn() as conn:
        return conn.execute(
            """
            SELECT date(event_at, 'unixepoch', 'localtime') as day,
                   SUM(CASE WHEN event_type='join' THEN 1 ELSE 0 END) as joins,
                   SUM(CASE WHEN event_type='leave' THEN 1 ELSE 0 END) as leaves
            FROM channel_member_events
            WHERE required_channel_id=? AND event_at>=?
            GROUP BY day
            ORDER BY day DESC
            """,
            (required_channel_id, since),
        ).fetchall()


def get_channel_hourly_breakdown(required_channel_id: int, hours: int = 24):
    since = int(time.time()) - hours * 3600
    with get_conn() as conn:
        return conn.execute(
            """
            SELECT strftime('%Y-%m-%d %H:00', event_at, 'unixepoch', 'localtime') as hour,
                   SUM(CASE WHEN event_type='join' THEN 1 ELSE 0 END) as joins,
                   SUM(CASE WHEN event_type='leave' THEN 1 ELSE 0 END) as leaves
            FROM channel_member_events
            WHERE required_channel_id=? AND event_at>=?
            GROUP BY hour
            ORDER BY hour DESC
            """,
            (required_channel_id, since),
        ).fetchall()


# ---------- زیرمجموعه‌گیری (رفرال) ----------

def get_referral_count(telegram_id: int) -> int:
    with get_conn() as conn:
        row = conn.execute("SELECT COUNT(*) c FROM users WHERE referred_by=?", (telegram_id,)).fetchone()
        return row["c"]


def get_points(telegram_id: int) -> int:
    with get_conn() as conn:
        row = conn.execute("SELECT points FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        return row["points"] if row else 0


def get_user(telegram_id: int):
    with get_conn() as conn:
        return conn.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()


def get_top_referrers(limit: int = 10):
    # توجه: بر اساس تعداد دعوت‌های تاییدشده مرتب می‌شه، نه موجودی فعلی امتیاز.
    # اینطوری خرج کردن امتیاز توسط کاربر (برای باز کردن دکمه‌ها) باعث افت رتبه‌ی او در این جدول نمی‌شه.
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT u.telegram_id, u.username, u.first_name, COUNT(r.telegram_id) as invited_count
            FROM users u
            JOIN users r ON r.referred_by = u.telegram_id AND r.referral_credited = 1
            GROUP BY u.telegram_id
            ORDER BY invited_count DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return rows


# ---------- کسر امتیاز برای باز کردن دکمه‌های امتیازی ----------
#
# باگ قبلی: وقتی کاربر امتیاز کافی برای دیدن پاسخ یک دکمه رو داشت، هیچ‌وقت امتیازش کسر
# نمی‌شد؛ در نتیجه با همون امتیازِ ثابت می‌تونست به‌صورت نامحدود دکمه‌های امتیازی دیگه رو هم
# باز کنه. رفتار درست: هر دکمه‌ی امتیازی، بار اولی که کاربر بازش می‌کنه امتیاز موردنیازش از
# کاربر کسر می‌شه (به‌صورت اتمیک، تا هم‌زمانی مشکل ایجاد نکنه) و اون دکمه برای همیشه برای
# همون کاربر باز/رایگان می‌مونه (رکورد در unlocked_buttons). دفعات بعدی که همون دکمه رو
# می‌زنه دیگه امتیاز کسر نمی‌شه.

def spend_points_for_button(telegram_id: int, button_id: int, cost: int):
    """
    تلاش می‌کنه امتیاز لازم برای باز کردن یک دکمه رو از کاربر کسر کنه.
    خروجی: (ok: bool, already_unlocked: bool, points_now: int)
      - ok=False یعنی امتیاز کافی نبود (کسری صورت نگرفت)
      - already_unlocked=True یعنی قبلاً باز شده بود، امتیاز دوباره کسر نشد
    """
    if cost <= 0:
        return True, True, get_points(telegram_id)
    with get_conn() as conn:
        already = conn.execute(
            "SELECT 1 FROM unlocked_buttons WHERE telegram_id=? AND button_id=?",
            (telegram_id, button_id),
        ).fetchone()
        if already:
            row = conn.execute("SELECT points FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
            return True, True, (row["points"] if row else 0)

        row = conn.execute("SELECT points FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        points = row["points"] if row else 0
        if points < cost:
            return False, False, points

        conn.execute(
            "UPDATE users SET points = points - ? WHERE telegram_id=? AND points >= ?",
            (cost, telegram_id, cost),
        )
        conn.execute(
            "INSERT OR IGNORE INTO unlocked_buttons (telegram_id, button_id, unlocked_at) VALUES (?,?,?)",
            (telegram_id, button_id, int(time.time())),
        )
        return True, False, points - cost


def is_button_unlocked(telegram_id: int, button_id: int) -> bool:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT 1 FROM unlocked_buttons WHERE telegram_id=? AND button_id=?",
            (telegram_id, button_id),
        ).fetchone()
        return bool(row)


# ---------- مدیریت چندادمینه ----------

def add_admin(telegram_id: int, added_by: int):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO admins (telegram_id, added_by, added_at) VALUES (?,?,?)",
            (telegram_id, added_by, int(time.time())),
        )


def remove_admin(telegram_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM admins WHERE telegram_id=?", (telegram_id,))


def get_db_admins():
    with get_conn() as conn:
        return [r["telegram_id"] for r in conn.execute("SELECT telegram_id FROM admins").fetchall()]


# ---------- پاسخ خودکار کلمه‌کلیدی ----------

def add_keyword(keyword: str, response_text: str, match_type: str = "contains") -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO keywords (keyword, response_text, match_type, created_at) VALUES (?,?,?,?)",
            (keyword.strip().lower(), response_text, match_type, int(time.time())),
        )
        return cur.lastrowid


def remove_keyword(keyword_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM keywords WHERE id=?", (keyword_id,))


def get_keywords():
    with get_conn() as conn:
        return conn.execute("SELECT * FROM keywords ORDER BY id ASC").fetchall()


def find_matching_keyword(message_text: str):
    """اولین کلیدواژه‌ای که با متن پیام مچ بشه رو برمی‌گردونه، وگرنه None"""
    if not message_text:
        return None
    text_lower = message_text.strip().lower()
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM keywords ORDER BY id ASC").fetchall()
    for row in rows:
        if row["match_type"] == "exact":
            if text_lower == row["keyword"]:
                return row
        else:
            if row["keyword"] in text_lower:
                return row
    return None
