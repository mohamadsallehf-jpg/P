"""
نقطه ورود ربات. اجرا: python main.py
"""
import logging

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ChatMemberHandler,
    MessageHandler,
    filters,
)

from config import BOT_TOKEN
import database as db
from handlers import user as user_handlers
from handlers import admin as admin_handlers

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
# سکوت کردن لاگ‌های شلوغ کتابخانه httpx
logging.getLogger("httpx").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)


def main():
    db.init_db()
    logger.info("دیتابیس آماده شد.")

    app = Application.builder().token(BOT_TOKEN).build()

    # دستورات کاربر عادی
    app.add_handler(CommandHandler("start", user_handlers.start))

    # دستور ادمین
    app.add_handler(CommandHandler("admin", admin_handlers.admin_entry))

    # لغو یک مرحله‌ی چندمرحله‌ای ادمین (اگه گیر کرد)
    app.add_handler(CommandHandler("cancel", admin_handlers.admin_cancel))

    # کلیک روی دکمه ناوبری کاربر (nav:...)
    app.add_handler(CallbackQueryHandler(user_handlers.navigate, pattern=r"^nav:"))

    # کلیک روی دکمه «عضو شدم، بررسی کن»
    app.add_handler(CallbackQueryHandler(user_handlers.check_join_callback, pattern=r"^checkjoin$"))

    # کلیک روی دکمه «حساب من»
    app.add_handler(CallbackQueryHandler(user_handlers.myaccount_callback, pattern=r"^myaccount$"))

    # کلیک روی دکمه‌های پنل ادمین (adm:...)
    app.add_handler(CallbackQueryHandler(admin_handlers.admin_callback, pattern=r"^adm:"))

    # ردیابی جوین/لفت کاربران در کانال‌های جوین اجباری (برای آمار جذب در پنل ادمین)
    app.add_handler(ChatMemberHandler(user_handlers.channel_member_update, ChatMemberHandler.CHAT_MEMBER))

    # ورودی‌های متن/عکس/ویدیو/فایل ادمین (برای مراحل چندمرحله‌ای مثل ساخت دکمه، تعیین پاسخ، پیام همگانی)
    admin_input_filter = (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.Document.ALL) & ~filters.COMMAND
    app.add_handler(MessageHandler(admin_input_filter, admin_handlers.admin_message_input), group=0)

    # پاسخ خودکار کلمه‌کلیدی (گروه جدا تا مزاحم مراحل چندمرحله‌ای ادمین نشه)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, user_handlers.keyword_autoreply), group=1)

    logger.info("ربات در حال اجراست...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
