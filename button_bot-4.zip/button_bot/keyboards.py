"""
توابع کمکی برای ساخت کیبوردهای شیشه‌ای (Inline Keyboard)
"""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

import database as db


# ---------- کیبورد سمت کاربر عادی ----------

def user_menu_keyboard(parent_id):
    """کیبورد نمایش دکمه‌های یک سطح برای کاربر عادی"""
    children = db.get_children(parent_id)
    rows = []
    for child in children:
        prefix = "🟢 " if child["required_points"] == 0 else "🏆 "
        rows.append([InlineKeyboardButton(f"{prefix}{child['text']}", callback_data=f"nav:{child['id']}")])
    if parent_id is None:
        rows.append([InlineKeyboardButton("👤 حساب من", callback_data="myaccount")])
    if parent_id is not None:
        parent = db.get_button(parent_id)
        grandparent_id = parent["parent_id"] if parent else None
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"nav:{grandparent_id if grandparent_id is not None else 'root'}")])
    return InlineKeyboardMarkup(rows) if rows else None


# ---------- کیبورد پنل ادمین ----------

def admin_main_keyboard(is_owner=False):
    rows = [
        [InlineKeyboardButton("🗂 مدیریت دکمه‌ها", callback_data="adm:tree:root")],
        [InlineKeyboardButton("📊 آمار ربات", callback_data="adm:stats")],
        [InlineKeyboardButton("📢 پیام همگانی (به کاربران)", callback_data="adm:broadcast")],
        [InlineKeyboardButton("📤 ارسال پیام به کانال", callback_data="adm:sendchannel")],
        [InlineKeyboardButton("⚙️ تنظیمات پیام خوش‌آمد", callback_data="adm:welcome")],
        [InlineKeyboardButton("🚫 مدیریت کاربران (بن/آنبن)", callback_data="adm:users")],
        [InlineKeyboardButton("🔒 جوین اجباری", callback_data="adm:channels")],
        [InlineKeyboardButton("👥 زیرمجموعه‌گیری", callback_data="adm:referrals")],
        [InlineKeyboardButton("🤖 پاسخ خودکار کلمه‌کلیدی", callback_data="adm:keywords")],
    ]
    if is_owner:
        rows.append([InlineKeyboardButton("🛡 مدیریت ادمین‌ها", callback_data="adm:admins")])
    rows.append([InlineKeyboardButton("🔐 قفل/بازکردن ربات", callback_data="adm:togglelock")])
    return InlineKeyboardMarkup(rows)


def referrals_keyboard():
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="adm:home")]])


def keywords_management_keyboard():
    keywords = db.get_keywords()
    rows = []
    for kw in keywords:
        rows.append([InlineKeyboardButton(f"❌ حذف: {kw['keyword']}", callback_data=f"adm:delkeyword:{kw['id']}")])
    rows.append([InlineKeyboardButton("➕ افزودن کلمه کلیدی جدید", callback_data="adm:add_keyword")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="adm:home")])
    return InlineKeyboardMarkup(rows)


def admins_management_keyboard(db_admin_ids, owner_ids):
    rows = []
    for aid in owner_ids:
        rows.append([InlineKeyboardButton(f"👑 {aid} (مالک، غیرقابل‌حذف)", callback_data="noop")])
    for aid in db_admin_ids:
        rows.append([InlineKeyboardButton(f"❌ حذف: {aid}", callback_data=f"adm:deladmin:{aid}")])
    rows.append([InlineKeyboardButton("➕ افزودن ادمین جدید", callback_data="adm:add_admin")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="adm:home")])
    return InlineKeyboardMarkup(rows)


def channels_management_keyboard():
    channels = db.get_required_channels()
    rows = []
    for ch in channels:
        label = ch["title"] or ch["chat_identifier"]
        row = [
            InlineKeyboardButton(f"📊 آمار: {label}", callback_data=f"adm:chanstats:{ch['id']}"),
            InlineKeyboardButton("❌ حذف", callback_data=f"adm:delchannel:{ch['id']}"),
        ]
        rows.append(row)
        if not ch["invite_link"]:
            rows.append([InlineKeyboardButton(f"🔗 ساخت لینک اختصاصی: {label}", callback_data=f"adm:genlink:{ch['id']}")])
    rows.append([InlineKeyboardButton("➕ افزودن کانال جدید", callback_data="adm:add_channel")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="adm:home")])
    return InlineKeyboardMarkup(rows)


def channel_stats_keyboard(channel_id):
    rows = [
        [InlineKeyboardButton("📅 آمار روزانه (۳۰ روز)", callback_data=f"adm:chanstats_daily:{channel_id}")],
        [InlineKeyboardButton("⏰ آمار ساعتی (۲۴ ساعت)", callback_data=f"adm:chanstats_hourly:{channel_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="adm:channels")],
    ]
    return InlineKeyboardMarkup(rows)


def send_channel_choice_keyboard():
    channels = db.get_required_channels()
    rows = []
    for ch in channels:
        rows.append([InlineKeyboardButton(f"📤 {ch['title'] or ch['chat_identifier']}", callback_data=f"adm:sendchannel_to:{ch['id']}")])
    rows.append([InlineKeyboardButton("✏️ آیدی کانال دیگه (دستی)", callback_data="adm:sendchannel_custom")])
    rows.append([InlineKeyboardButton("🔙 انصراف", callback_data="adm:home")])
    return InlineKeyboardMarkup(rows)


def admin_tree_keyboard(parent_id):
    """نمایش درخت دکمه‌ها برای مدیریت (ادمین)"""
    children = db.get_children(parent_id)
    rows = []
    for idx, child in enumerate(children):
        has_children = len(db.get_children(child["id"])) > 0
        prefix = "📁 " if has_children else "🔘 "
        rows.append([
            InlineKeyboardButton(f"{prefix}{child['text']}", callback_data=f"adm:open:{child['id']}"),
        ])
        move_row = []
        if idx > 0:
            move_row.append(InlineKeyboardButton("⬆️", callback_data=f"adm:move:up:{child['id']}"))
        if idx < len(children) - 1:
            move_row.append(InlineKeyboardButton("⬇️", callback_data=f"adm:move:down:{child['id']}"))
        move_row.append(InlineKeyboardButton("✏️ ویرایش نام", callback_data=f"adm:rename:{child['id']}"))
        move_row.append(InlineKeyboardButton("❌ حذف", callback_data=f"adm:delete:{child['id']}"))
        rows.append(move_row)

    rows.append([InlineKeyboardButton("➕ افزودن دکمه جدید در این سطح", callback_data=f"adm:add:{parent_id if parent_id is not None else 'root'}")])

    if parent_id is not None:
        btn = db.get_button(parent_id)
        rows.append([InlineKeyboardButton("📝 تعیین/ویرایش پاسخ این دکمه", callback_data=f"adm:setresp:{parent_id}")])
        grandparent_id = btn["parent_id"] if btn else None
        rows.append([InlineKeyboardButton("🔙 یک سطح بالاتر", callback_data=f"adm:tree:{grandparent_id if grandparent_id is not None else 'root'}")])

    rows.append([InlineKeyboardButton("🏠 بازگشت به پنل ادمین", callback_data="adm:home")])
    return InlineKeyboardMarkup(rows)


def admin_button_detail_keyboard(button_id, parent_id):
    rows = [
        [InlineKeyboardButton("📝 تعیین/ویرایش پاسخ", callback_data=f"adm:setresp:{button_id}")],
        [InlineKeyboardButton("🏆 تعیین امتیاز لازم برای دیدن پاسخ", callback_data=f"adm:setpoints:{button_id}")],
        [InlineKeyboardButton("🗂 مشاهده/افزودن زیرمنو", callback_data=f"adm:tree:{button_id}")],
        [InlineKeyboardButton("✏️ ویرایش نام", callback_data=f"adm:rename:{button_id}")],
        [InlineKeyboardButton("❌ حذف این دکمه", callback_data=f"adm:delete:{button_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"adm:tree:{parent_id if parent_id is not None else 'root'}")],
    ]
    return InlineKeyboardMarkup(rows)


def response_type_keyboard(button_id):
    rows = [
        [InlineKeyboardButton("✏️ متن", callback_data=f"adm:resptype:text:{button_id}")],
        [InlineKeyboardButton("🖼 عکس", callback_data=f"adm:resptype:photo:{button_id}")],
        [InlineKeyboardButton("🎬 ویدیو", callback_data=f"adm:resptype:video:{button_id}")],
        [InlineKeyboardButton("📄 فایل", callback_data=f"adm:resptype:document:{button_id}")],
        [InlineKeyboardButton("🚫 بدون پاسخ (فقط زیرمنو)", callback_data=f"adm:resptype:none:{button_id}")],
        [InlineKeyboardButton("🔙 انصراف", callback_data=f"adm:open:{button_id}")],
    ]
    return InlineKeyboardMarkup(rows)


def cancel_keyboard(callback_data="adm:home"):
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 انصراف", callback_data=callback_data)]])


def confirm_delete_keyboard(button_id, parent_id):
    rows = [
        [
            InlineKeyboardButton("✅ بله، حذف کن", callback_data=f"adm:delconfirm:{button_id}"),
            InlineKeyboardButton("❌ انصراف", callback_data=f"adm:open:{button_id}"),
        ]
    ]
    return InlineKeyboardMarkup(rows)


def broadcast_confirm_keyboard():
    rows = [
        [
            InlineKeyboardButton("✅ ارسال به همه", callback_data="adm:bcconfirm"),
            InlineKeyboardButton("❌ انصراف", callback_data="adm:home"),
        ]
    ]
    return InlineKeyboardMarkup(rows)


def users_management_keyboard():
    rows = [
        [InlineKeyboardButton("🚫 بن کردن کاربر (با آیدی عددی)", callback_data="adm:ban")],
        [InlineKeyboardButton("✅ آنبن کردن کاربر (با آیدی عددی)", callback_data="adm:unban")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="adm:home")],
    ]
    return InlineKeyboardMarkup(rows)
