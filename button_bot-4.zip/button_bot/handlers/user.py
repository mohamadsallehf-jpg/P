"""
هندلرهای مربوط به کاربر عادی: /start، پیمایش بین دکمه‌ها، حساب کاربری، جوین اجباری و سیستم امتیاز/رفرال.
"""
import logging

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import BadRequest
from telegram.ext import ContextTypes

import database as db
import keyboards as kb
from config import DEFAULT_WELCOME_TEXT

logger = logging.getLogger(__name__)


# ---------- ابزار کمکی: رندر امن پیام (رفع باگ «برگشت کار نمی‌کند») ----------
#
# باگ اصلی این بود: وقتی پاسخ یک دکمه از نوع عکس/ویدیو/فایل بود، پیام به‌صورت رسانه‌ای
# ارسال می‌شد. وقتی کاربر روی «بازگشت» می‌زد، کد سعی می‌کرد با edit_message_text متن پیام
# رسانه‌ای رو عوض کنه که تلگرام این کارو رد می‌کنه (چون نمی‌شه کپشن عکس رو با ادیت متن عوض کرد).
# این تابع همیشه اول ادیت رو امتحان می‌کنه، و اگه شکست خورد (هر دلیلی)، پیام قبلی رو پاک
# کرده و یک پیام متنی جدید و تازه می‌فرسته. این‌طوری «بازگشت» همیشه کار می‌کنه.

async def safe_render(query, context: ContextTypes.DEFAULT_TYPE, chat_id: int, text: str, markup=None):
    try:
        await query.edit_message_text(text, reply_markup=markup)
        return
    except BadRequest:
        pass
    except Exception:
        pass
    try:
        await query.message.delete()
    except Exception:
        pass
    await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=markup)


# ---------- جوین اجباری ----------

async def _get_unjoined_channels(context: ContextTypes.DEFAULT_TYPE, user_id: int):
    """لیست کانال‌های اجباری‌ای که کاربر هنوز عضوشون نیست رو برمی‌گردونه"""
    channels = db.get_required_channels()
    unjoined = []
    for ch in channels:
        try:
            member = await context.bot.get_chat_member(ch["chat_identifier"], user_id)
            if member.status in ("left", "kicked"):
                unjoined.append(ch)
        except Exception:
            # اگه ربات ادمین کانال نباشه یا کانال پیدا نشه، از چک صرف‌نظر می‌کنیم
            continue
    return unjoined


def _join_keyboard(channels):
    rows = []
    for ch in channels:
        ident = ch["chat_identifier"]
        url = ch["invite_link"] or (f"https://t.me/{ident.lstrip('@')}" if ident.startswith("@") else None)
        if url:
            rows.append([InlineKeyboardButton(f"📢 عضویت در {ch['title'] or ident}", url=url)])
    rows.append([InlineKeyboardButton("✅ عضو شدم، بررسی کن", callback_data="checkjoin")])
    return InlineKeyboardMarkup(rows)


async def _finish_join_and_show_menu(update_or_query, context, user, is_callback: bool):
    """بعد از تایید موفق عضویت: امتیاز رفرال (اگه لازمه) اعطا می‌شه و منوی اصلی نشون داده می‌شه"""
    referrer_id = db.credit_referral_if_confirmed(user.id)
    if referrer_id:
        inviter_name = user.first_name or (f"@{user.username}" if user.username else str(user.id))
        try:
            await context.bot.send_message(
                chat_id=referrer_id,
                text=(
                    f"🎉 تبریک! ۱ امتیاز به شما اضافه شد.\n"
                    f"👤 توسط: {inviter_name} (آیدی: {user.id})\n\n"
                    f"امتیاز فعلی‌تون رو از «👤 حساب من» ببینید."
                ),
            )
        except Exception:
            pass

    welcome = db.get_setting("welcome_text", DEFAULT_WELCOME_TEXT)
    markup = kb.user_menu_keyboard(None)

    if is_callback:
        query = update_or_query
        await safe_render(query, context, user.id, welcome, markup)
    else:
        message = update_or_query
        await message.reply_text(welcome, reply_markup=markup)


async def check_join_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    وقتی کاربر روی «✅ عضو شدم، بررسی کن» می‌زنه:
    - اگه هنوز عضو بعضی کانال‌ها نیست: فقط همون کانال‌های نشده رو نشون بده (بقیه خودکار از لیست حذف بشن)
    - اگه عضو همه شده: امتیاز رفرال اعطا بشه (در صورت لزوم) و منوی اصلی باز بشه
    """
    query = update.callback_query
    user = update.effective_user

    unjoined = await _get_unjoined_channels(context, user.id)
    if unjoined:
        await query.answer("هنوز عضو بعضی کانال‌ها نیستی! فقط اونایی که مونده رو زیر می‌بینی.", show_alert=True)
        await safe_render(
            query, context, user.id,
            "این کانال‌ها هنوز عضو نشدی، لطفاً عضو شو و دوباره بررسی کن:",
            _join_keyboard(unjoined),
        )
        return

    await query.answer("✅ عضویت تأیید شد!")
    await _finish_join_and_show_menu(query, context, user, is_callback=True)


# ---------- استارت ----------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    # پارس لینک رفرال: /start ref_123456789
    referred_by = None
    if context.args:
        arg = context.args[0]
        if arg.startswith("ref_") and arg[4:].isdigit():
            referred_by = int(arg[4:])

    db.upsert_user(user.id, user.username, user.first_name, referred_by)

    if db.is_banned(user.id):
        await update.message.reply_text("⛔️ دسترسی شما به این ربات مسدود شده است.")
        return

    if db.get_setting("bot_locked", "0") == "1":
        await update.message.reply_text("🔒 ربات موقتاً در دسترس نیست. لطفاً بعداً دوباره امتحان کن.")
        return

    unjoined = await _get_unjoined_channels(context, user.id)
    if unjoined:
        await update.message.reply_text(
            "👋 خوش اومدی!\nبرای استفاده از ربات، اول باید عضو کانال(های) زیر بشی:",
            reply_markup=_join_keyboard(unjoined),
        )
        return

    await _finish_join_and_show_menu(update.message, context, user, is_callback=False)


# ---------- حساب کاربری ----------

async def myaccount_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = update.effective_user
    await query.answer()

    bot_username = (await context.bot.get_me()).username
    row = db.get_user(user.id)
    points = row["points"] if row else 0
    total_invited = db.get_referral_count(user.id)
    ref_link = f"https://t.me/{bot_username}?start=ref_{user.id}"

    text = (
        "👤 حساب کاربری شما\n\n"
        f"🆔 آیدی عددی: {user.id}\n"
        f"📛 نام: {user.first_name or '—'}\n"
        f"🏆 امتیاز فعلی: {points}\n"
        f"👥 تعداد کل دعوت‌شده‌ها: {total_invited}\n\n"
        f"🔗 لینک اختصاصی دعوت شما:\n{ref_link}\n\n"
        "با هر لینک، وقتی دوستت عضو کانال‌های ربات بشه و روی «عضو شدم، بررسی کن» بزنه، "
        "۱ امتیاز به شما اضافه می‌شه."
    )
    rows = [[InlineKeyboardButton("🔙 بازگشت", callback_data="nav:root")]]
    await safe_render(query, context, user.id, text, InlineKeyboardMarkup(rows))


# ---------- ناوبری اصلی ----------

async def navigate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """هندل کلیک روی دکمه‌های اینلاین سمت کاربر (callback_data با پیشوند nav:)"""
    query = update.callback_query
    user = update.effective_user

    if db.is_banned(user.id):
        await query.answer("⛔️ دسترسی شما مسدود شده است.", show_alert=True)
        return

    if db.get_setting("bot_locked", "0") == "1":
        await query.answer("🔒 ربات موقتاً در دسترس نیست.", show_alert=True)
        return

    unjoined = await _get_unjoined_channels(context, user.id)
    if unjoined:
        await query.answer("اول باید عضو کانال‌های اجباری بشی!", show_alert=True)
        await safe_render(
            query, context, user.id,
            "برای استفاده از ربات، اول باید عضو کانال(های) زیر بشی:",
            _join_keyboard(unjoined),
        )
        return

    await query.answer()
    raw_target = query.data.split(":", 1)[1]
    target_id = None if raw_target == "root" else int(raw_target)

    if target_id is None:
        welcome = db.get_setting("welcome_text", DEFAULT_WELCOME_TEXT)
        markup = kb.user_menu_keyboard(None)
        await safe_render(query, context, user.id, welcome, markup)
        return

    button = db.get_button(target_id)
    if not button:
        await safe_render(query, context, user.id, "این دکمه دیگر وجود ندارد.", kb.user_menu_keyboard(None))
        return

    # ---------- چک و کسر امتیاز لازم ----------
    # رفع باگ: قبلاً فقط موجودی امتیاز چک می‌شد ولی هیچ‌وقت کسر نمی‌شد، در نتیجه کاربر با
    # همون امتیاز ثابت می‌تونست بی‌نهایت دکمه‌ی امتیازی باز کنه. الان با spend_points_for_button
    # امتیاز به‌صورت اتمیک کسر می‌شه؛ هر دکمه فقط بار اول که باز میشه امتیاز کم می‌کنه و بعدش
    # برای همیشه برای همون کاربر آزاد می‌مونه.
    required_points = button["required_points"] or 0
    newly_unlocked = False
    remaining_points = None
    if required_points > 0:
        ok, already_unlocked, points_info = db.spend_points_for_button(user.id, target_id, required_points)
        if not ok:
            user_points = points_info
            bot_username = (await context.bot.get_me()).username
            ref_link = f"https://t.me/{bot_username}?start=ref_{user.id}"
            back_parent = button["parent_id"]
            text = (
                f"🔒 برای دریافت پاسخ «{button['text']}» به {required_points} امتیاز نیاز داری.\n"
                f"🏆 امتیاز فعلی شما: {user_points}\n\n"
                "چطور امتیاز بگیرم؟\n"
                "دوستاتو با لینک اختصاصی زیر دعوت کن. وقتی هرکدوم عضو کانال(های) ربات بشن "
                "و روی «عضو شدم، بررسی کن» بزنن، ۱ امتیاز به شما اضافه می‌شه:\n\n"
                f"{ref_link}\n\n"
                "⚠️ توجه: خودِ فرد دعوت‌شده هم باید حتماً عضو کانال‌های ربات بشه و تایید کنه؛ "
                "وگرنه امتیازی به شما اضافه نمی‌شه."
            )
            rows = [[InlineKeyboardButton(
                "🔙 بازگشت", callback_data=f"nav:{back_parent if back_parent is not None else 'root'}"
            )]]
            await safe_render(query, context, user.id, text, InlineKeyboardMarkup(rows))
            return
        newly_unlocked = not already_unlocked
        remaining_points = points_info

    if newly_unlocked:
        try:
            await context.bot.send_message(
                chat_id=user.id,
                text=(
                    f"🏆 {required_points} امتیاز برای باز کردن «{button['text']}» کسر شد.\n"
                    f"امتیاز باقی‌مانده: {remaining_points}"
                ),
            )
        except Exception:
            pass

    db.log_click(target_id, user.id)
    markup = kb.user_menu_keyboard(target_id)

    resp_type = button["response_type"]
    if resp_type != "none":
        caption = button["response_text"] or ""
        file_id = button["response_file_id"]

        if resp_type == "text":
            await safe_render(query, context, user.id, caption or button["text"], markup)
            return

        # برای رسانه (عکس/ویدیو/فایل): پیام قبلی حذف و یک پیام رسانه‌ای تازه ارسال می‌شه
        try:
            await query.message.delete()
        except Exception:
            pass
        try:
            if resp_type == "photo":
                await context.bot.send_photo(chat_id=user.id, photo=file_id, caption=caption, reply_markup=markup)
            elif resp_type == "video":
                await context.bot.send_video(chat_id=user.id, video=file_id, caption=caption, reply_markup=markup)
            elif resp_type == "document":
                await context.bot.send_document(chat_id=user.id, document=file_id, caption=caption, reply_markup=markup)
        except Exception:
            await context.bot.send_message(chat_id=user.id, text=caption or button["text"], reply_markup=markup)
        return

    # بدون پاسخ اختصاصی؛ فقط زیرمنو را نشان بده
    if markup is None:
        await safe_render(query, context, user.id, f"«{button['text']}»\n\nهنوز محتوایی برای این بخش تعریف نشده است.", None)
    else:
        await safe_render(query, context, user.id, button["text"], markup)


# ---------- پاسخ خودکار کلمه‌کلیدی ----------

async def keyword_autoreply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """اگه متن پیام با یکی از کلمات کلیدی تعریف‌شده مچ بشه، پاسخ خودکار می‌ده"""
    if not update.message or not update.message.text:
        return
    # رفع باگ: این هندلر تو گروه جدا (group=1) بعد از هندلر ورودی‌های ادمین (group=0) اجرا می‌شه.
    # قبلاً فقط context.user_data['awaiting'] چک می‌شد؛ ولی هندلر ادمین معمولاً همون لحظه که
    # پیام رو پردازش می‌کنه awaiting رو پاک می‌کنه (pop) و بعد این هندلر اجرا می‌شه و awaiting
    # دیگه خالیه. نتیجه: اگه متنی که ادمین برای مثلاً «تغییر نام دکمه» یا «پیام همگانی» فرستاده
    # به‌صورت اتفاقی با یک کلمه‌کلیدی مچ بشه، هم پاسخ ادمین رو می‌گیره هم پاسخ خودکار کلمه‌کلیدی
    # (پیام تکراری/گمراه‌کننده). الان با پرچم _admin_consumed_last_message که هندلر ادمین ست
    # می‌کنه، از این تداخل جلوگیری می‌کنیم.
    if context.user_data.pop("_admin_consumed_last_message", False):
        return
    match = db.find_matching_keyword(update.message.text)
    if match:
        await update.message.reply_text(match["response_text"])


# ---------- ردیابی عضویت در کانال‌های جوین اجباری (برای آمار جذب) ----------

async def channel_member_update(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    وقتی وضعیت عضویت یک کاربر در کانالی که ربات ادمینشه تغییر کنه (join/leave)، تلگرام آپدیت
    chat_member می‌فرسته. اگه اون چت یکی از کانال‌های جوین اجباری باشه، رویداد رو ذخیره
    می‌کنیم تا در پنل ادمین بشه آمار جذب روزانه/ساعتی/ماهانه رو دید.
    """
    cmu = update.chat_member
    if not cmu:
        return
    channel = db.find_required_channel_by_chat_id(cmu.chat.id)
    if not channel:
        return

    old_status = cmu.old_chat_member.status
    new_status = cmu.new_chat_member.status
    member_statuses = ("member", "administrator", "creator", "restricted")
    was_member = old_status in member_statuses
    is_member = new_status in member_statuses

    if not was_member and is_member:
        db.log_channel_member_event(channel["id"], cmu.new_chat_member.user.id, "join")
    elif was_member and not is_member:
        db.log_channel_member_event(channel["id"], cmu.new_chat_member.user.id, "leave")
