"""
هندلرهای پنل ادمین. همه‌چیز با دکمه‌های شیشه‌ای کار می‌کنه.
برای مراحلی که نیاز به ورودی متنی/رسانه‌ای دارن (مثل تایپ نام دکمه یا آپلود عکس پاسخ)،
از context.user_data['awaiting'] به عنوان state ساده استفاده می‌کنیم.
"""
import logging
import asyncio

from telegram import Update
from telegram.error import RetryAfter
from telegram.ext import ContextTypes

import database as db
import keyboards as kb
from config import ADMIN_IDS, DEFAULT_WELCOME_TEXT

logger = logging.getLogger(__name__)


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS or user_id in db.get_db_admins()


def is_owner(user_id: int) -> bool:
    """فقط ادمین‌هایی که تو .env تعریف شدن (owner واقعی) اجازه مدیریت بقیه ادمین‌ها رو دارن"""
    return user_id in ADMIN_IDS


def _parse_target(raw: str):
    return None if raw == "root" else int(raw)


async def admin_entry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دستور /admin"""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("این دستور فقط برای ادمین‌های ربات در دسترس است.")
        return
    context.user_data.pop("awaiting", None)
    await update.message.reply_text("🛠 به پنل مدیریت ربات خوش اومدی:", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))


async def admin_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دستور /cancel: اگه ادمین وسط یه مرحله‌ی چندمرحله‌ای گیر کرده باشه (مثلاً منتظر عکس/متنه)
    و بخواد بدون کلیک روی دکمه‌ی «انصراف» ازش خارج بشه، با این دستور می‌تونه لغو کنه."""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        return
    had_awaiting = context.user_data.pop("awaiting", None) is not None
    context.user_data.pop("broadcast_pending", None)
    msg = "✅ عملیات لغو شد." if had_awaiting else "چیزی برای لغو کردن وجود نداشت."
    await update.message.reply_text(msg, reply_markup=kb.admin_main_keyboard(is_owner(user_id)))


async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await query.answer("دسترسی ندارید.", show_alert=True)
        return

    await query.answer()
    parts = query.data.split(":")
    # adm:action:...
    action = parts[1]

    if action == "home":
        context.user_data.pop("awaiting", None)
        await query.edit_message_text("🛠 پنل مدیریت ربات:", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))

    elif action == "tree":
        target = _parse_target(parts[2])
        title = "🗂 مدیریت دکمه‌های سطح اصلی:" if target is None else f"🗂 زیرمنوی «{db.get_button(target)['text']}»:"
        await query.edit_message_text(title, reply_markup=kb.admin_tree_keyboard(target))

    elif action == "open":
        button_id = int(parts[2])
        btn = db.get_button(button_id)
        if not btn:
            await query.edit_message_text("این دکمه دیگر وجود ندارد.", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))
            return
        resp_map = {"none": "بدون پاسخ (فقط زیرمنو)", "text": "متن", "photo": "عکس", "video": "ویدیو", "document": "فایل"}
        info = (
            f"🔘 دکمه: «{btn['text']}»\n"
            f"نوع پاسخ فعلی: {resp_map.get(btn['response_type'], btn['response_type'])}\n"
            f"🏆 امتیاز لازم: {btn['required_points']}\n"
            f"تعداد زیرمنوها: {len(db.get_children(button_id))}"
        )
        await query.edit_message_text(info, reply_markup=kb.admin_button_detail_keyboard(button_id, btn["parent_id"]))

    elif action == "add":
        parent = _parse_target(parts[2])
        context.user_data["awaiting"] = {"action": "add_button_text", "parent_id": parent}
        await query.edit_message_text(
            "✏️ متن (اسم) دکمه جدید رو بفرست:",
            reply_markup=kb.cancel_keyboard(f"adm:tree:{parts[2]}"),
        )

    elif action == "rename":
        button_id = int(parts[2])
        context.user_data["awaiting"] = {"action": "rename_button", "button_id": button_id}
        await query.edit_message_text(
            "✏️ نام جدید دکمه رو بفرست:",
            reply_markup=kb.cancel_keyboard(f"adm:open:{button_id}"),
        )

    elif action == "delete":
        button_id = int(parts[2])
        btn = db.get_button(button_id)
        child_count = len(db.get_children(button_id))
        warn = f"\n⚠️ توجه: {child_count} زیرمنو هم همراه این دکمه حذف می‌شود." if child_count else ""
        await query.edit_message_text(
            f"آیا از حذف دکمه «{btn['text']}» مطمئنی؟{warn}",
            reply_markup=kb.confirm_delete_keyboard(button_id, btn["parent_id"]),
        )

    elif action == "delconfirm":
        button_id = int(parts[2])
        btn = db.get_button(button_id)
        parent_id = btn["parent_id"] if btn else None
        db.delete_button(button_id)
        await query.edit_message_text(
            "✅ دکمه حذف شد.",
            reply_markup=kb.admin_tree_keyboard(parent_id),
        )

    elif action == "move":
        direction = parts[2]
        button_id = int(parts[3])
        db.move_button(button_id, direction)
        btn = db.get_button(button_id)
        await query.edit_message_reply_markup(reply_markup=kb.admin_tree_keyboard(btn["parent_id"]))

    elif action == "setresp":
        button_id = int(parts[2])
        await query.edit_message_text(
            "نوع پاسخ این دکمه رو انتخاب کن:",
            reply_markup=kb.response_type_keyboard(button_id),
        )

    elif action == "setpoints":
        button_id = int(parts[2])
        context.user_data["awaiting"] = {"action": "set_points", "button_id": button_id}
        btn = db.get_button(button_id)
        await query.edit_message_text(
            f"🏆 امتیاز لازم فعلی برای «{btn['text']}»: {btn['required_points']}\n\n"
            "عدد امتیاز جدید رو بفرست (۰ یعنی بدون نیاز به امتیاز، همه می‌تونن ببینن):",
            reply_markup=kb.cancel_keyboard(f"adm:open:{button_id}"),
        )

    elif action == "resptype":
        resp_type = parts[2]
        button_id = int(parts[3])
        if resp_type == "none":
            db.set_button_response(button_id, "none", None, None)
            btn = db.get_button(button_id)
            await query.edit_message_text(
                "✅ این دکمه بدون پاسخ اختصاصی شد (فقط زیرمنو نمایش داده می‌شود).",
                reply_markup=kb.admin_button_detail_keyboard(button_id, btn["parent_id"]),
            )
            return
        context.user_data["awaiting"] = {"action": "set_response", "button_id": button_id, "response_type": resp_type}
        prompts = {
            "text": "✏️ متن پاسخ رو بفرست:",
            "photo": "🖼 عکس مورد نظر رو بفرست (می‌تونی توضیح/کپشن هم اضافه کنی):",
            "video": "🎬 ویدیوی مورد نظر رو بفرست:",
            "document": "📄 فایل مورد نظر رو بفرست:",
        }
        await query.edit_message_text(prompts[resp_type], reply_markup=kb.cancel_keyboard(f"adm:open:{button_id}"))

    elif action == "stats":
        stats = db.get_stats()
        top = db.get_top_buttons(5)
        top_text = "\n".join(f"  • {t} — {c} کلیک" for t, c in top) if top else "  (هنوز داده‌ای نیست)"
        text = (
            "📊 آمار ربات:\n\n"
            f"👥 کل کاربران: {stats['total_users']}\n"
            f"🟢 فعال در ۲۴ ساعت اخیر: {stats['active_today']}\n"
            f"🚫 بن‌شده: {stats['banned_users']}\n"
            f"🔘 تعداد دکمه‌ها: {stats['total_buttons']}\n"
            f"👆 کل کلیک‌ها: {stats['total_clicks']}\n\n"
            f"🏆 پرکلیک‌ترین دکمه‌ها:\n{top_text}"
        )
        await query.edit_message_text(text, reply_markup=kb.cancel_keyboard("adm:home"))

    elif action == "broadcast":
        context.user_data["awaiting"] = {"action": "broadcast_message"}
        await query.edit_message_text(
            "📢 پیامی که می‌خوای برای همه کاربران ارسال بشه رو بفرست (متن، عکس، ویدیو یا فایل):",
            reply_markup=kb.cancel_keyboard("adm:home"),
        )

    elif action == "sendchannel":
        channels = db.get_required_channels()
        if not channels:
            await query.edit_message_text(
                "هنوز هیچ کانالی تعریف نشده. اول از «🔒 جوین اجباری» یه کانال اضافه کن، "
                "یا مستقیم آیدی کانال رو دستی وارد کن:",
                reply_markup=kb.send_channel_choice_keyboard(),
            )
            return
        await query.edit_message_text(
            "📤 پیام رو کجا می‌خوای پست کنی؟",
            reply_markup=kb.send_channel_choice_keyboard(),
        )

    elif action == "sendchannel_to":
        channel_row_id = int(parts[2])
        channels = {c["id"]: c for c in db.get_required_channels()}
        ch = channels.get(channel_row_id)
        if not ch:
            await query.edit_message_text("این کانال دیگه در لیست نیست.", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))
            return
        context.user_data["awaiting"] = {"action": "sendchannel_message", "chat_identifier": ch["chat_identifier"]}
        await query.edit_message_text(
            f"پیام (متن/عکس/ویدیو/فایل) رو بفرست تا در «{ch['title'] or ch['chat_identifier']}» پست بشه:",
            reply_markup=kb.cancel_keyboard("adm:home"),
        )

    elif action == "sendchannel_custom":
        context.user_data["awaiting"] = {"action": "sendchannel_custom_id"}
        await query.edit_message_text(
            "آیدی کانال مقصد رو بفرست (@username یا -100...):\n"
            "⚠️ ربات باید تو اون کانال ادمین با دسترسی ارسال پست باشه.",
            reply_markup=kb.cancel_keyboard("adm:home"),
        )

    elif action == "bcconfirm":
        pending = context.user_data.pop("broadcast_pending", None)
        if not pending:
            await query.edit_message_text("پیامی برای ارسال یافت نشد.", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))
            return
        await query.edit_message_text("⏳ در حال ارسال به همه کاربران... این پیام پس از اتمام آپدیت می‌شود.")
        user_ids = db.get_all_user_ids(only_active=True)
        sent, failed = 0, 0
        # نکته امنیتی/پایداری: تلگرام برای پیام به چت‌های مختلف حداکثر ~۳۰ پیام در ثانیه رو مجازه.
        # قبلاً بدون هیچ تاخیری تو یه حلقه ارسال می‌شد که برای لیست‌های بزرگ باعث Flood-limit
        # (و حتی محدود شدن موقت ربات توسط تلگرام) می‌شد. الان با یه تاخیر کوچیک بین پیام‌ها
        # و مدیریت خطای RetryAfter، ارسال امن و پایدار انجام می‌شه.
        for uid in user_ids:
            for attempt in range(2):
                try:
                    await context.bot.copy_message(chat_id=uid, from_chat_id=pending["chat_id"], message_id=pending["message_id"])
                    sent += 1
                    break
                except RetryAfter as e:
                    await asyncio.sleep(e.retry_after + 0.5)
                    continue
                except Exception:
                    failed += 1
                    break
            await asyncio.sleep(0.05)  # ~۲۰ پیام در ثانیه، امن و زیر سقف تلگرام
        await query.edit_message_text(
            f"✅ پیام همگانی ارسال شد.\nموفق: {sent}\nناموفق: {failed}",
            reply_markup=kb.admin_main_keyboard(is_owner(user_id)),
        )

    elif action == "welcome":
        context.user_data["awaiting"] = {"action": "welcome_text"}
        current = db.get_setting("welcome_text", DEFAULT_WELCOME_TEXT)
        await query.edit_message_text(
            f"متن فعلی پیام خوش‌آمد:\n\n«{current}»\n\nمتن جدید رو بفرست:",
            reply_markup=kb.cancel_keyboard("adm:home"),
        )

    elif action == "users":
        await query.edit_message_text("🚫 مدیریت کاربران:", reply_markup=kb.users_management_keyboard())

    elif action == "ban":
        context.user_data["awaiting"] = {"action": "ban_user"}
        await query.edit_message_text("آیدی عددی کاربری که می‌خوای بن کنی رو بفرست:", reply_markup=kb.cancel_keyboard("adm:users"))

    elif action == "unban":
        context.user_data["awaiting"] = {"action": "unban_user"}
        await query.edit_message_text("آیدی عددی کاربری که می‌خوای آنبن کنی رو بفرست:", reply_markup=kb.cancel_keyboard("adm:users"))

    elif action == "channels":
        channels = db.get_required_channels()
        info = "🔒 کانال‌های جوین اجباری فعلی:\n\n"
        if channels:
            lines = []
            for c in channels:
                net = db.get_channel_join_stats(c["id"])["net"]
                link_note = "" if c["invite_link"] else " ⚠️ بدون لینک اختصاصی"
                lines.append(f"• {c['title'] or c['chat_identifier']} — 👥 {net} عضو جذب‌شده{link_note}")
            info += "\n".join(lines)
        else:
            info += "(هنوز کانالی تعریف نشده — کاربرا بدون محدودیت وارد ربات می‌شن)"
        info += (
            "\n\n⚠️ نکته مهم: برای اینکه ربات بتونه عضویت رو چک کنه و لینک اختصاصی بسازه، "
            "باید خودِ ربات از قبل توی هر کانال، **ادمین** با دسترسی «دعوت کاربران» باشه."
        )
        await query.edit_message_text(info, reply_markup=kb.channels_management_keyboard())

    elif action == "genlink":
        channel_id = int(parts[2])
        ch = db.get_required_channel(channel_id)
        if not ch:
            await query.edit_message_text("این کانال دیگه در لیست نیست.", reply_markup=kb.channels_management_keyboard())
            return
        try:
            chat = await context.bot.get_chat(ch["chat_identifier"])
            link_obj = await context.bot.create_chat_invite_link(
                chat_id=chat.id, name=f"جوین اجباری - {(ch['title'] or '')[:25]}"
            )
            db.update_channel_link(channel_id, link_obj.invite_link, chat.id)
            await query.edit_message_text(
                f"✅ لینک اختصاصی برای «{ch['title'] or ch['chat_identifier']}» ساخته شد.",
                reply_markup=kb.channels_management_keyboard(),
            )
        except Exception as e:
            await query.edit_message_text(
                f"❌ ساخت لینک ناموفق بود: {e}\nمطمئن شو ربات تو این کانال ادمین با دسترسی «دعوت کاربران» است.",
                reply_markup=kb.channels_management_keyboard(),
            )

    elif action == "chanstats":
        channel_id = int(parts[2])
        ch = db.get_required_channel(channel_id)
        if not ch:
            await query.edit_message_text("این کانال دیگه در لیست نیست.", reply_markup=kb.channels_management_keyboard())
            return
        s = db.get_channel_join_stats(channel_id)
        text = (
            f"📊 آمار جذب کانال «{ch['title'] or ch['chat_identifier']}»\n\n"
            f"👥 مجموع اعضای جذب‌شده تا الان: {s['net']}\n"
            f"   (کل جوین‌ها: {s['total_join']} — کل ترک‌ها: {s['total_leave']})\n\n"
            f"📈 امروز (۲۴ ساعت اخیر): {s['today']}\n"
            f"📅 هفته اخیر (۷ روز): {s['week']}\n"
            f"🗓 ماه اخیر (۳۰ روز): {s['month']}\n\n"
            "برای دیدن جزئیات روز‌به‌روز یا ساعت‌به‌ساعت از دکمه‌های زیر استفاده کن:"
        )
        await query.edit_message_text(text, reply_markup=kb.channel_stats_keyboard(channel_id))

    elif action == "chanstats_daily":
        channel_id = int(parts[2])
        ch = db.get_required_channel(channel_id)
        if not ch:
            await query.edit_message_text("این کانال دیگه در لیست نیست.", reply_markup=kb.channels_management_keyboard())
            return
        rows = db.get_channel_daily_breakdown(channel_id, days=30)
        if rows:
            lines = [f"{r['day']}:  🟢 {r['joins']} جوین   🔴 {r['leaves']} ترک" for r in rows]
            body = "\n".join(lines)
        else:
            body = "(هنوز داده‌ای برای ۳۰ روز اخیر ثبت نشده)"
        text = f"📅 آمار روزانه «{ch['title'] or ch['chat_identifier']}» (۳۰ روز اخیر):\n\n{body}"
        await query.edit_message_text(text, reply_markup=kb.cancel_keyboard(f"adm:chanstats:{channel_id}"))

    elif action == "chanstats_hourly":
        channel_id = int(parts[2])
        ch = db.get_required_channel(channel_id)
        if not ch:
            await query.edit_message_text("این کانال دیگه در لیست نیست.", reply_markup=kb.channels_management_keyboard())
            return
        rows = db.get_channel_hourly_breakdown(channel_id, hours=24)
        if rows:
            lines = [f"{r['hour']}:  🟢 {r['joins']} جوین   🔴 {r['leaves']} ترک" for r in rows]
            body = "\n".join(lines)
        else:
            body = "(هنوز داده‌ای برای ۲۴ ساعت اخیر ثبت نشده)"
        text = f"⏰ آمار ساعتی «{ch['title'] or ch['chat_identifier']}» (۲۴ ساعت اخیر):\n\n{body}"
        await query.edit_message_text(text, reply_markup=kb.cancel_keyboard(f"adm:chanstats:{channel_id}"))

    elif action == "add_channel":
        context.user_data["awaiting"] = {"action": "add_channel"}
        await query.edit_message_text(
            "آیدی کانال رو بفرست (مثل @mychannel یا آیدی عددی -1001234567890).\n"
            "⚠️ قبلش ربات رو تو اون کانال ادمین کن.",
            reply_markup=kb.cancel_keyboard("adm:channels"),
        )

    elif action == "delchannel":
        channel_id = int(parts[2])
        db.remove_required_channel(channel_id)
        await query.edit_message_text("✅ کانال حذف شد.", reply_markup=kb.channels_management_keyboard())

    elif action == "referrals":
        bot_username = (await context.bot.get_me()).username
        top = db.get_top_referrers(10)
        if top:
            lines = []
            for i, r in enumerate(top, start=1):
                name = r["first_name"] or r["username"] or str(r["telegram_id"])
                lines.append(f"{i}. {name} — {r['invited_count']} نفر دعوت‌شده")
            text = "👥 برترین‌های زیرمجموعه‌گیری:\n\n" + "\n".join(lines)
        else:
            text = "👥 هنوز هیچ‌کسی از طریق لینک رفرال کسی رو دعوت نکرده."
        text += f"\n\n🔗 فرمت لینک رفرال هر کاربر:\nhttps://t.me/{bot_username}?start=ref_<آیدی_عددی_کاربر>"
        await query.edit_message_text(text, reply_markup=kb.referrals_keyboard())

    elif action == "keywords":
        keywords = db.get_keywords()
        info = "🤖 کلمات کلیدی پاسخ خودکار:\n\n"
        if keywords:
            info += "\n".join(f"• «{k['keyword']}»" for k in keywords)
        else:
            info += "(هنوز چیزی تعریف نشده)"
        await query.edit_message_text(info, reply_markup=kb.keywords_management_keyboard())

    elif action == "add_keyword":
        context.user_data["awaiting"] = {"action": "add_keyword_word"}
        await query.edit_message_text(
            "کلمه یا عبارت کلیدی رو بفرست (مثلاً: قیمت):",
            reply_markup=kb.cancel_keyboard("adm:keywords"),
        )

    elif action == "delkeyword":
        keyword_id = int(parts[2])
        db.remove_keyword(keyword_id)
        await query.edit_message_text("✅ کلمه کلیدی حذف شد.", reply_markup=kb.keywords_management_keyboard())

    elif action == "admins":
        if not is_owner(user_id):
            await query.answer("فقط مالک اصلی ربات می‌تونه ادمین‌ها رو مدیریت کنه.", show_alert=True)
            return
        db_admins = db.get_db_admins()
        await query.edit_message_text(
            "🛡 مدیریت ادمین‌های ربات:",
            reply_markup=kb.admins_management_keyboard(db_admins, ADMIN_IDS),
        )

    elif action == "add_admin":
        if not is_owner(user_id):
            await query.answer("فقط مالک اصلی ربات می‌تونه ادمین اضافه کنه.", show_alert=True)
            return
        context.user_data["awaiting"] = {"action": "add_admin"}
        await query.edit_message_text("آیدی عددی کاربری که می‌خوای ادمین کنی رو بفرست:", reply_markup=kb.cancel_keyboard("adm:admins"))

    elif action == "deladmin":
        if not is_owner(user_id):
            await query.answer("فقط مالک اصلی ربات می‌تونه ادمین حذف کنه.", show_alert=True)
            return
        target_id = int(parts[2])
        db.remove_admin(target_id)
        db_admins = db.get_db_admins()
        await query.edit_message_text(
            "✅ ادمین حذف شد.\n\n🛡 مدیریت ادمین‌های ربات:",
            reply_markup=kb.admins_management_keyboard(db_admins, ADMIN_IDS),
        )

    elif action == "togglelock":
        locked = db.get_setting("bot_locked", "0") == "1"
        db.set_setting("bot_locked", "0" if locked else "1")
        status = "🔓 ربات باز شد و کاربران عادی دوباره می‌تونن استفاده کنن." if locked else "🔒 ربات قفل شد. کاربران عادی تا وقتی بازش نکنی، دسترسی ندارن (ادمین‌ها بی‌تأثیرن)."
        await query.edit_message_text(status, reply_markup=kb.admin_main_keyboard(is_owner(user_id)))

    elif action == "noop":
        pass


async def admin_message_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    هندل یکپارچه‌ی همه‌ی ورودی‌های ادمین (متن، عکس، ویدیو، فایل) وقتی منتظر یک مقدار خاصه.
    """
    user_id = update.effective_user.id
    if not is_admin(user_id):
        return
    awaiting = context.user_data.get("awaiting")
    if not awaiting:
        return  # پیام عادی، نادیده گرفته می‌شود

    # این پیام قطعاً بخشی از یک مرحله‌ی ادمینه؛ هندلر پاسخ خودکار کلمه‌کلیدی (group=1) نباید
    # دوباره روی همین پیام واکنش نشون بده (رفع باگ تداخل بین دو هندلر).
    context.user_data["_admin_consumed_last_message"] = True

    action = awaiting["action"]
    message = update.message
    text = message.text.strip() if message.text else None

    # این اکشن‌ها با هر نوع پیامی (متن یا رسانه) کار می‌کنن
    if action == "set_response":
        await _save_response(update, context, awaiting["button_id"], awaiting["response_type"])
        return

    if action == "broadcast_message":
        context.user_data["broadcast_pending"] = {
            "chat_id": update.effective_chat.id,
            "message_id": message.message_id,
        }
        context.user_data.pop("awaiting", None)
        await message.reply_text(
            "این پیام دقیقاً همینطوری برای همه ارسال میشه. مطمئنی؟",
            reply_markup=kb.broadcast_confirm_keyboard(),
        )
        return

    if action == "sendchannel_message":
        chat_identifier = awaiting["chat_identifier"]
        try:
            await context.bot.copy_message(
                chat_id=chat_identifier,
                from_chat_id=update.effective_chat.id,
                message_id=message.message_id,
            )
            context.user_data.pop("awaiting", None)
            await message.reply_text("✅ پیام در کانال پست شد.", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))
        except Exception as e:
            await message.reply_text(
                f"❌ ارسال به کانال ناموفق بود: {e}\n\n"
                "مطمئن شو ربات تو اون کانال ادمینه و دسترسی ارسال پست داره."
            )
        return

    # بقیه‌ی اکشن‌ها فقط متن نیاز دارن
    if action == "add_button_text":
        if not text:
            await update.message.reply_text("لطفاً یک متن معتبر بفرست.")
            return
        parent_id = awaiting["parent_id"]
        new_id = db.add_button(parent_id, text)
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"✅ دکمه «{text}» ساخته شد.",
            reply_markup=kb.admin_tree_keyboard(parent_id),
        )

    elif action == "rename_button":
        button_id = awaiting["button_id"]
        db.rename_button(button_id, text)
        context.user_data.pop("awaiting", None)
        btn = db.get_button(button_id)
        await update.message.reply_text(
            "✅ نام دکمه بروزرسانی شد.",
            reply_markup=kb.admin_button_detail_keyboard(button_id, btn["parent_id"]),
        )

    elif action == "welcome_text":
        if not text:
            await update.message.reply_text("لطفاً یک پیام متنی بفرست.")
            return
        db.set_setting("welcome_text", text)
        context.user_data.pop("awaiting", None)
        await update.message.reply_text("✅ متن خوش‌آمد بروزرسانی شد.", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))

    elif action == "ban_user":
        if not text or not text.isdigit():
            await update.message.reply_text("آیدی عددی نامعتبره. دوباره بفرست:")
            return
        existed = db.set_ban(int(text), True)
        context.user_data.pop("awaiting", None)
        note = "" if existed else "\n(این کاربر هنوز /start نزده بود؛ ولی از این به بعد اگه بیاد، بلاک می‌مونه.)"
        await update.message.reply_text(f"✅ کاربر {text} بن شد.{note}", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))

    elif action == "unban_user":
        if not text or not text.isdigit():
            await update.message.reply_text("آیدی عددی نامعتبره. دوباره بفرست:")
            return
        db.set_ban(int(text), False)
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(f"✅ کاربر {text} آنبن شد.", reply_markup=kb.admin_main_keyboard(is_owner(user_id)))

    elif action == "add_channel":
        if not text:
            await update.message.reply_text("لطفاً آیدی کانال رو بفرست (مثل @mychannel یا -1001234567890).")
            return
        cid = text if (text.startswith("@") or text.lstrip("-").isdigit()) else f"@{text}"
        try:
            chat = await context.bot.get_chat(cid)
            title = chat.title or chat.username or cid
        except Exception:
            await update.message.reply_text(
                "❌ نتونستم این کانال رو پیدا کنم. مطمئن شو:\n"
                "۱. آیدی درست وارد شده (@username یا آیدی عددی -100...)\n"
                "۲. ربات از قبل توی اون کانال، ادمین شده\n"
                "دوباره بفرست یا انصراف بده:"
            )
            return

        # ساخت لینک دعوت اختصاصی و خصوصی همین کانال؛ جوین اجباری از این به بعد با همین لینک انجام
        # می‌شه (نه لینک عمومی @username کانال)، و چون لینک اختصاصیه، تلگرام آپدیت‌های عضویت رو
        # قابل ردیابی می‌کنه و می‌تونیم آمار جذب (روزانه/ساعتی/ماهانه) رو در پنل ادمین نشون بدیم.
        invite_link = None
        try:
            link_obj = await context.bot.create_chat_invite_link(
                chat_id=chat.id, name=f"جوین اجباری - {title[:25]}"
            )
            invite_link = link_obj.invite_link
        except Exception as e:
            logger.warning("ساخت لینک دعوت اختصاصی برای کانال %s شکست خورد: %s", cid, e)

        db.add_required_channel(cid, title, invite_link, chat.id)
        context.user_data.pop("awaiting", None)
        note = "" if invite_link else (
            "\n\n⚠️ نتونستم لینک اختصاصی بسازم (احتمالاً ربات دسترسی «دعوت کاربران» رو نداره). "
            "فعلاً از لینک عمومی کانال استفاده می‌شه؛ از دکمه‌ی «🔗 ساخت لینک اختصاصی» می‌تونی دوباره امتحان کنی."
        )
        await update.message.reply_text(
            f"✅ کانال «{title}» به لیست جوین اجباری اضافه شد.{note}",
            reply_markup=kb.channels_management_keyboard(),
        )

    elif action == "sendchannel_custom_id":
        if not text:
            await update.message.reply_text("لطفاً آیدی کانال رو بفرست.")
            return
        cid = text if (text.startswith("@") or text.lstrip("-").isdigit()) else f"@{text}"
        try:
            await context.bot.get_chat(cid)
        except Exception:
            await update.message.reply_text(
                "❌ نتونستم این کانال رو پیدا کنم. مطمئن شو ربات تو اون کانال ادمینه. دوباره بفرست:"
            )
            return
        context.user_data["awaiting"] = {"action": "sendchannel_message", "chat_identifier": cid}
        await update.message.reply_text(f"حالا پیامی که می‌خوای در {cid} پست بشه رو بفرست:")

    elif action == "set_points":
        if not text or not text.isdigit():
            await update.message.reply_text("لطفاً فقط یک عدد بفرست (مثلاً 10):")
            return
        button_id = awaiting["button_id"]
        db.set_button_points(button_id, int(text))
        context.user_data.pop("awaiting", None)
        btn = db.get_button(button_id)
        await update.message.reply_text(
            f"✅ امتیاز لازم برای «{btn['text']}» روی {text} تنظیم شد.",
            reply_markup=kb.admin_button_detail_keyboard(button_id, btn["parent_id"]),
        )

    elif action == "add_keyword_word":
        if not text:
            await update.message.reply_text("لطفاً یک کلمه یا عبارت بفرست.")
            return
        context.user_data["awaiting"] = {"action": "add_keyword_response", "keyword": text}
        await update.message.reply_text(f"حالا متن پاسخ خودکار برای «{text}» رو بفرست:")

    elif action == "add_keyword_response":
        if not text:
            await update.message.reply_text("لطفاً یک پیام متنی بفرست.")
            return
        keyword = awaiting["keyword"]
        db.add_keyword(keyword, text)
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"✅ کلمه کلیدی «{keyword}» با پاسخ خودکار ذخیره شد.",
            reply_markup=kb.keywords_management_keyboard(),
        )

    elif action == "add_admin":
        if not is_owner(user_id):
            await update.message.reply_text("فقط مالک اصلی ربات می‌تونه ادمین اضافه کنه.")
            return
        if not text or not text.isdigit():
            await update.message.reply_text("آیدی عددی نامعتبره. دوباره بفرست:")
            return
        db.add_admin(int(text), user_id)
        context.user_data.pop("awaiting", None)
        db_admins = db.get_db_admins()
        await update.message.reply_text(
            f"✅ کاربر {text} به‌عنوان ادمین اضافه شد.",
            reply_markup=kb.admins_management_keyboard(db_admins, ADMIN_IDS),
        )


async def _save_response(update, context, button_id, response_type):
    message = update.message
    caption = message.caption or message.text or ""
    file_id = None

    if response_type == "text":
        if not message.text:
            await message.reply_text("لطفاً یک پیام متنی بفرست.")
            return
        caption = message.text
    elif response_type == "photo":
        if not message.photo:
            await message.reply_text("لطفاً یک عکس بفرست.")
            return
        file_id = message.photo[-1].file_id
    elif response_type == "video":
        if not message.video:
            await message.reply_text("لطفاً یک ویدیو بفرست.")
            return
        file_id = message.video.file_id
    elif response_type == "document":
        if not message.document:
            await message.reply_text("لطفاً یک فایل بفرست.")
            return
        file_id = message.document.file_id

    db.set_button_response(button_id, response_type, caption, file_id)
    context.user_data.pop("awaiting", None)
    btn = db.get_button(button_id)
    await message.reply_text(
        "✅ پاسخ این دکمه ذخیره شد.",
        reply_markup=kb.admin_button_detail_keyboard(button_id, btn["parent_id"]),
    )
